---
name: kooyahq-cli
description: Use the local KooyaHQ CLI and MCP tools safely for projects, boards, tickets, work sessions, allocations, users, analytics, and notifications.
---

# KooyaHQ CLI

Use this skill when the user asks to inspect or change KooyaHQ through `kooyahq` or its local MCP tools.

Configure with a personal API key. If the account has multiple company memberships, pass `--company <uuid>` on every organization command or include the `company` field on each MCP call; selection is not sticky. The API also requires an enabled per-member company API grant and the operation's current business permission. Company Knowledge uses the selected company's path grants. For Knowledge updates, read the current document revision and use an expected revision plus a stable idempotency key. Retry uncertain outcomes with the same key and request. See `docs/knowledge.md` in the installed package for client setup.

## Start with discovery

Call `kooyahq_discover` before relying on a remembered command contract. Use a narrow scope such as `boards`, `tickets move`, or `time sessions start`. The equivalent offline CLI contract is:

```sh
kooyahq --skill boards --output json
kooyahq --skill tickets move --output json
```

Use the exact command name and argument keys returned by discovery. Prefer exact selectors such as `board-id`, `board-key`, `ticket-id`, and `ticket-key`; never guess an ID or silently substitute a fuzzy name.

For organization UI actions without a dedicated command, use `kooyahq api operations` or the MCP tool `kooyahq_api_discover`. The compact list limits agent context. Pass `operationId` to inspect its parameters and JSON body schema. Call with `kooyahq api request` or `kooyahq_api_call`; every non-GET request requires `--yes` or `confirm: true`. The contract excludes platform operations, and the server reuses the normal company membership, API grant, role permission, and resource checks. Use `kooyahq media upload` for bounded file upload. Declared binary API responses require `--output-file` (or MCP `outputFile`); signed storage capability routes remain hidden from discovery.

## Reads and mutations

Use `kooyahq_call` with the exact discovered command. Reads do not need confirmation. Every non-GET CLI command prompts before sending unless `--yes` is explicit; every non-GET MCP call requires `confirm: true`. Destructive commands also have their documented command-specific confirmation. For consequential changes, preview with `dryRun: true`, inspect the exact target and payload, then repeat with confirmation. There is no global project display-name field. For every mutation:

1. Include `company` when the account belongs to multiple organizations.
2. Use the exact command name, UUID/key selector, and body fields returned by discovery.
3. Use `dryRun: true` where supported, then inspect the method, path, query, and body.
4. Supply `confirm: true`; the MCP bridge requires it for every non-GET command.
5. Read the affected resource again and verify the result.
6. Clean up temporary boards, tickets, allocations, or test data created for verification.

The API authorizes the acting member for each company and resource. The CLI and MCP never expose platform-console administration.

## Boards and tickets

Discover the board first, keep its exact ID or key, then discover the ticket command. For moves and reorders, use the semantic placement returned by discovery: `before`, `after`, `first`, or `last`. Read the ticket and destination board before moving, then read them again afterward. Do not edit the database directly; all changes must pass through the KooyaHQ CLI API.

## Work sessions and allocations

Use a project UUID in the session allocation JSON. Read live sessions and allocations before lifecycle changes so the command uses current resource IDs and versions:

```sh
kooyahq projects list --all --output json
kooyahq time live --scope mine --output json
kooyahq time sessions start --allocations '[{"projectId":"123e4567-e89b-42d3-a456-426614174000","description":"Release review"}]'
kooyahq time allocations pause --allocation-id 123e4567-e89b-42d3-a456-426614174001 --expected-version 2 --reason "Break"
kooyahq time allocations resume --allocation-id 123e4567-e89b-42d3-a456-426614174001 --expected-version 3
kooyahq time allocations stop --allocation-id 123e4567-e89b-42d3-a456-426614174001 --expected-version 4
kooyahq time allocations add-task --allocation-id 123e4567-e89b-42d3-a456-426614174001 --task "Review handoff"
kooyahq time sessions end --session-id 123e4567-e89b-42d3-a456-426614174002 --expected-version 5
```

Session start validates one to twenty unique project allocations locally and the backend rechecks organization membership, project availability, authorization, and lifecycle versions. Team reads require explicit `--scope team` and remain subject to server authorization. Old `time timers` command names are not available in the current CLI.

## Codex MCP status

KooyaHQ is a local stdio server and uses the credential profile saved by `kooyahq configure`. Codex may show `Auth: Unsupported`; that is expected because MCP-level OAuth is not used. It does not mean KooyaHQ API authentication is disabled.

`Tools: none`, `No such file or directory`, or an incomplete startup warning is a real startup/configuration failure. Run:

```sh
kooyahq mcp doctor --client codex
kooyahq mcp install --client codex
```

Then restart Codex and open a new thread. Use `--online` with doctor only when an authenticated `whoami` network check is wanted.
