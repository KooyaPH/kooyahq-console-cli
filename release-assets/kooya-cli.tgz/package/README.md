# KooyaHQ CLI and MCP

The `@kooya/cli` release package provides the `kooyahq` command-line client and
`kooyahq-mcp` local stdio MCP server for macOS, Windows, and Linux.

It requires Node.js 22. The default origin is
`https://console.hq.kooyaai.com`, and every request uses the unified `/api/v1`
surface. Tenant entity identifiers and the selected organization are canonical
UUIDs.

## Install and update

Install Node.js 22 or newer, then run:

```sh
npm install -g https://github.com/KooyaPH/kooyahq-console-cli/releases/latest/download/kooya-cli.tgz
kooyahq --version
kooyahq-mcp --version
```

Check for the latest stable public release or update an npm global installation:

```sh
kooyahq update --check
kooyahq update
kooyahq mcp doctor --client codex
```

`update` does not change your saved profile. If you run from source, `npx`, or
another install method, use `npm install -g https://github.com/KooyaPH/kooyahq-console-cli/releases/latest/download/kooya-cli.tgz` manually.

The earlier public `kooyahq-cli` package uses the same command names. Remove it
with `npm uninstall -g kooyahq-cli` before installing this package. Its stored
profile has no organization UUID and is not migrated automatically; configure
this CLI with the organization UUID and a credential accepted by the current
API. The saved profile is replaced only after validation succeeds.

## Configure

Interactive configuration prompts for the Console origin, organization UUID,
access key ID, and secret access key. It verifies `GET /api/v1/whoami` before
atomically replacing the private local profile.

```sh
kooyahq configure
kooyahq configure show
kooyahq auth whoami --output json
```

For non-interactive use, all four variables are required together:

```sh
export KOOYAHQ_BASE_URL=https://console.hq.kooyaai.com
export KOOYAHQ_ORGANIZATION_ID=123e4567-e89b-42d3-a456-426614174000
export KOOYAHQ_ACCESS_KEY_ID=your-access-key-id
export KOOYAHQ_SECRET_ACCESS_KEY=your-secret-access-key
kooyahq auth whoami --output json
```

The organization UUID is sent as `X-Kooya-Organization-Id` on every request.
Both Console operator keys and Headquarters member keys need an organization
UUID for CLI configuration. The API verifies the key scope and the user's
current permissions on every request.

Configuration is stored at `~/.kooyahq/config.json` on Linux/macOS and
`%USERPROFILE%\.kooyahq\config.json` on Windows. POSIX directories use mode
`0700`, files use `0600`, and Windows profiles receive private ACLs. Secrets
are entered by hidden prompt, written atomically, redacted from output, and
never accepted as command-line flags.

## Command and identifier compatibility

All network operations use `/api/v1`. Entity ID selectors validate canonical
lowercase UUID values before sending traffic. Human-friendly board and ticket
keys such as `OPS` and `OPS-42` remain supported where the API exposes them.
Deprecated positional selectors remain temporarily available, but map to the
same UUID fields.

The established command surface covers projects, boards, tickets, comments,
criteria, relations, blockers, imports, time tracking, analytics, budgets,
users, permissions, notifications, chat, and events. Chat remains HTTP
request/response (`chat conversations list|get`, `chat messages list|send`,
`chat conversations read`). Live chat signals use `events watch` (CLI process)
or `events poll` / `events cursor` (MCP). Headquarters receivers need no CLI
change because CLI send reuses the same collaborate message write path.
`time reports` is an analytics read and requires `work.time.analytics`; it
accepts an optional paired date range (up to 366 inclusive days) and an
optional member UUID, with no pagination or sorting.
Discover exact parameters without credentials or network traffic:

```sh
kooyahq --help
kooyahq tickets create --help
kooyahq --skill tickets create --output json
kooyahq events cursor --channels chat --output json
kooyahq events poll --since CURSOR --channels chat --output json
kooyahq events watch --channels chat
```

- `events cursor` — bootstrap the latest cursor.
- `events poll --since CURSOR` — one-shot buffer read for MCP / `kooyahq_call` loops.
- `events watch` — long-lived SSE side process (CLI only); writes one JSON object
  per line. MCP hosts must not call `events watch`; use `events poll` /
  `events cursor` over MCP instead, or run `kooyahq events watch` as a separate
  CLI process.

Mutations support dry-run and explicit confirmation. MCP mutations additionally
require an exact live project display name, `confirm: true`, and preserve the
same server-side authorization and audit boundary.

## MCP clients

After configuration succeeds:

```sh
kooyahq mcp install --client codex
kooyahq mcp doctor --client codex
kooyahq mcp doctor --client codex --online
```

Restart Codex and open a new thread after installation. Cursor, Claude Code,
Gemini CLI and Google Antigravity have automatic local installers. Hermes
exposes a reviewed manual descriptor. Browser-hosted clients require a
separately secured remote gateway and cannot start this local stdio process.

The MCP server exposes three stable tools:

- `kooyahq_status` validates the active profile.
- `kooyahq_discover` returns the machine-readable command contract.
- `kooyahq_call` executes one exact command using structured flag arguments.

## Project safety gate

Before any KooyaHQ mutation, run
`kooyahq projects list --all --output json`. The mutation's top-level `project`
must be the exact live project display name returned by that command. If no
exact project display name matches the work, do not create, update, move,
comment on, or time-track anything. The MCP bridge rejects `projects create`
because project creation requires separately verified platform authorization.

## Safety and limits

- Blank, partial, or malformed configuration fails before network traffic.
- HTTPS is mandatory except for localhost development.
- Redirects are rejected so credentials cannot cross origins.
- GET transport failures have bounded retries; mutations are never retried.
- Requests time out and response bodies are size-limited.
- Paginated `--all` reads have hard page, item, and byte limits.
- Destructive commands require confirmation and remain permission-gated.
- Reflected credentials are redacted from API errors.
- Human-readable tables remove terminal control characters.
- Access keys are revocable server-side and every accepted operation is audited.

See [installation details](docs/installation.md),
[Codex MCP setup](docs/codex-mcp.md), and [safe scenarios](docs/scenarios.md).
