# KooyaHQ CLI and MCP

The `@kooya/cli` release package provides the `kooyahq` command-line client and
`kooyahq-mcp` local stdio MCP server for macOS, Windows, and Linux.

It requires Node.js 22. The default origin is
`https://console.hq.kooyaai.com`. Application requests use the unified `/api/v1`
surface; the feature-gated Knowledge content commands use restricted SSH after
API bootstrap. Tenant entity identifiers and company selectors are canonical UUIDs.

## Install and update

Install Node.js 22 or newer, then run:

```sh
npm install -g https://github.com/KooyaPH/kooyahq-console-cli/releases/latest/download/kooya-cli.tgz
kooyahq --version
kooyahq-mcp --version
```

Check for the latest stable public release or update an npm global installation:

```sh
kooyahq update --check
kooyahq update
kooyahq mcp doctor --client codex
```

`update` does not change your saved profile. If you run from source, `npx`, or
another install method, use `npm install -g https://github.com/KooyaPH/kooyahq-console-cli/releases/latest/download/kooya-cli.tgz` manually.

The earlier public `kooyahq-cli` package uses the same command names. Remove it
with `npm uninstall -g kooyahq-cli` before installing this package. Its profile
is not migrated automatically; configure this Console CLI with a personal API
key from your KooyaHQ Account Settings. Old company-bound credentials remain in
a time-limited compatibility period and must pass `--company <uuid>` on every
command while you migrate. The CLI reports the exact UTC transition window
whenever a legacy key is used.

## Configure

Interactive configuration prompts for the Console origin, access key ID, and
secret access key. Use the personal API key you create in Account Settings. The
CLI verifies `GET /api/v1/organization-api/companies` before atomically saving
the private local profile; it does not store a selected company.

```sh
kooyahq configure
kooyahq configure show
kooyahq auth whoami --output json
```

For non-interactive use, all three variables are required together:

```sh
export KOOYAHQ_BASE_URL=https://console.hq.kooyaai.com
export KOOYAHQ_ACCESS_KEY_ID=your-access-key-id
export KOOYAHQ_SECRET_ACCESS_KEY=your-secret-access-key
kooyahq projects list --company 123e4567-e89b-42d3-a456-426614174000 --output json
```

For one active company membership, the CLI selects it automatically. Accounts
with multiple memberships must pass `--company <uuid>` on every company
operation; the CLI discovers memberships and prints their names and UUIDs when
the selector is missing. The CLI exchanges the personal key for a five-minute
company lease. The API checks company membership, the company's per-member API
grant, and the current business permission for each request. A company owner or
administrator with member-management permission can grant or revoke API access
for employees from the organization's People page. Revocation takes effect on
the next API request.

Configuration is stored at `~/.kooyahq/config.json` on Linux/macOS and
`%USERPROFILE%\.kooyahq\config.json` on Windows. POSIX directories use mode
`0700`, files use `0600`, and Windows profiles receive private ACLs. Secrets
are entered by hidden prompt, written atomically, redacted from output, and
never accepted as command-line flags.

## Command and identifier compatibility

Application operations use `/api/v1`. Entity ID selectors validate canonical
lowercase UUID values before sending traffic. Human-friendly board and ticket
keys such as `OPS` and `OPS-42` remain supported where the API exposes them.
Deprecated positional selectors remain temporarily available, but map to the
same UUID fields.

The established command surface covers projects, boards, tickets, comments,
criteria, relations, blockers, imports, time tracking, analytics, budgets,
users, permissions, notifications, chat, and events. Chat remains HTTP
request/response (`chat conversations list|get`, `chat messages list|send`,
`chat conversations read`). Live chat signals use `events watch` (CLI process)
or `events poll` / `events cursor` (MCP). Headquarters receivers need no CLI
change because CLI send reuses the same collaborate message write path.
`time reports` is an analytics read and requires `work.time.analytics`; it
accepts an optional paired date range (up to 366 inclusive days) and an
optional member UUID, with no pagination or sorting.
Discover exact parameters without credentials or network traffic. Files can be
uploaded through `media upload`, and declared binary API responses can be saved
with `--output-file`:

```sh
kooyahq --help
kooyahq tickets create --help
kooyahq --skill tickets create --output json
kooyahq events cursor --channels chat --output json
kooyahq events poll --since CURSOR --channels chat --output json
kooyahq events watch --channels chat
kooyahq media upload --file ./receipt.pdf --purpose attachment --content-type application/pdf --company 123e4567-e89b-42d3-a456-426614174000 --yes
kooyahq api request organization.media.content.download --path-params '{"objectId":"123e4567-e89b-42d3-a456-426614174001"}' --output-file ./download.bin
```

- `events cursor` — bootstrap the latest cursor.
- `events poll --since CURSOR` — one-shot buffer read for MCP / `kooyahq_call` loops.
- `events watch` — long-lived SSE side process (CLI only); writes one JSON object
  per line. MCP hosts must not call `events watch`; use `events poll` /
  `events cursor` over MCP instead, or run `kooyahq events watch` as a separate
  CLI process.

Mutations support dry-run and explicit confirmation. Every non-GET CLI command
prompts before sending unless `--yes` is supplied. Every non-GET MCP call
requires `confirm: true`. Destructive commands also use their documented
command-specific confirmation. All operations preserve the same server-side
authorization and audit boundary.

## Company Knowledge (unreleased feature)

`kooyahq knowledge search|read|list|stat|create|patch|replace|batch|delete|history|receipt`
uses the selected company's node and current path grants. It requires an enabled
control plane, configured company binding, OpenSSH client and reachable node.
Connections are reused automatically by a private local helper. Use
`kooyahq-mcp --knowledge` for the compact read-only search/read tools, or
`--knowledge-write` to additionally expose stat/update/batch. Company Knowledge does
not require a project display name. See [Knowledge client setup](docs/knowledge.md).

## MCP clients

After configuration succeeds:

```sh
kooyahq mcp install --client codex
kooyahq mcp doctor --client codex
kooyahq mcp doctor --client codex --online
```

Restart Codex and open a new thread after installation. Cursor, Claude Code,
Gemini CLI and Google Antigravity have automatic local installers. Hermes
exposes a reviewed manual descriptor. Browser-hosted clients require a
separately secured remote gateway and cannot start this local stdio process.

The default MCP profile exposes five stable tools:

- `kooyahq_status` validates the active profile.
- `kooyahq_discover` returns the machine-readable command contract.
- `kooyahq_call` executes one exact command using structured flag arguments.
- `kooyahq_api_discover` returns compact organization API operations or one detailed operation schema.
- `kooyahq_api_call` invokes one discovered organization operation with per-call company selection.

The `media upload` helper uses a bounded signed transfer and finalizes the
company media object through the API. Generic API discovery excludes signed
storage capability routes. Binary API responses require `--output-file` (or
`outputFile` over MCP), are capped at 100 MiB, and are written privately without
overwriting an existing file unless explicitly forced. Knowledge document
content continues to use the dedicated restricted SSH commands.

Use `kooyahq api operations` to find approved organization API operations that
do not yet have a dedicated CLI command. Inspect one operation with
`kooyahq api operations --operation <operation-id>`, then call it with
`kooyahq api request`. Generic mutations require `--yes`; MCP mutations
require `confirm: true`. The calls use company leases and the same server-side
authorization checks. See [Organization API discovery and requests](docs/organization-api.md).

## Safety and limits

- Blank, partial, or malformed configuration fails before network traffic.
- HTTPS is mandatory except for localhost development.
- Redirects are rejected so credentials cannot cross origins.
- GET transport failures have bounded retries; mutations are never retried.
- Requests time out and response bodies are size-limited.
- Paginated `--all` reads have hard page, item, and byte limits.
- Destructive commands require confirmation and remain permission-gated.
- Reflected credentials are redacted from API errors.
- Human-readable tables remove terminal control characters.
- Access keys are revocable server-side and every accepted operation is audited.
- The CLI and MCP expose organization-scoped operations; platform console
  administration is not available through these credentials.

See [installation details](docs/installation.md),
[organization API discovery and requests](docs/organization-api.md),
[credential migration and recovery](docs/credential-migration.md),
[Codex MCP setup](docs/codex-mcp.md), and [safe scenarios](docs/scenarios.md).
