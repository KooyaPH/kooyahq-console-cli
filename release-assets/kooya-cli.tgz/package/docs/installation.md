# Install the KooyaHQ CLI and local MCP server

The public `@kooya/cli` release package includes both `kooyahq` and `kooyahq-mcp`.
It requires Node.js 22 or newer on macOS, Windows, or Linux. The default API is
`https://console.hq.kooyaai.com/api/v1`. Entity and organization identifiers
are UUID values.

## Install

Run these commands in Terminal, PowerShell, or your Linux shell:

```sh
npm install -g https://github.com/KooyaPH/kooyahq-console-cli/releases/latest/download/kooya-cli.tgz
kooyahq --version
kooyahq-mcp --version
```

The release tarball is available from the [public GitHub releases](https://github.com/KooyaPH/kooyahq-console-cli/releases).

### Replace an earlier GitHub CLI install

The earlier public `kooyahq-cli` package uses the same command names. Remove it
before installing this Console CLI so its global command links do not conflict:

```sh
npm uninstall -g kooyahq-cli
npm install -g https://github.com/KooyaPH/kooyahq-console-cli/releases/latest/download/kooya-cli.tgz
kooyahq configure
```

The earlier profile is not migrated automatically. Create a personal API key in
your KooyaHQ Account Settings, then configure this Console CLI with that key.
Company-bound keys from the previous flow remain available only during the
time-limited migration period; use `--company <uuid>` on each command until you
switch to a personal key. The server reports the exact UTC start and deadline
on legacy-key responses, and the CLI prints that window after each such call.

## Configure a profile

Run `kooyahq configure`. Supply:

1. Console base origin, normally `https://console.hq.kooyaai.com`.
2. The access key ID for your personal API key.
3. The one-time secret access key.

The client validates a personal key by discovering active company memberships
with `GET /api/v1/organization-api/companies`. It stores the personal key
without a company binding. Before company operations, it obtains a five-minute
lease for the selected company. A single membership is selected automatically;
multiple memberships require `--company <uuid>` on every company command.
Company API grants and business permissions are checked by the API on every
operation.

Automation must provide all three personal-key variables together:

```sh
export KOOYAHQ_BASE_URL=https://console.hq.kooyaai.com
export KOOYAHQ_ACCESS_KEY_ID=your-access-key-id
export KOOYAHQ_SECRET_ACCESS_KEY=your-secret-access-key
kooyahq projects list --company 123e4567-e89b-42d3-a456-426614174000 --output json
```

Do not set `KOOYAHQ_ORGANIZATION_ID` for a personal key. That variable is
accepted only for the bounded legacy company-key migration path.

Missing, blank, partial, non-UUID, non-HTTPS, or path-bearing configuration is
rejected before network traffic. HTTP is accepted only for localhost.

## Verify and update

```sh
kooyahq update --check
kooyahq update
kooyahq configure show
kooyahq auth whoami --output json
```

`update` installs the latest stable GitHub release asset only when the current CLI is
an npm global installation. For a source checkout, `npx`, or another install
method, run `npm install -g https://github.com/KooyaPH/kooyahq-console-cli/releases/latest/download/kooya-cli.tgz` manually. Your saved profile is
not changed by the updater. After an update, check the MCP registration:

```sh
kooyahq mcp doctor --client codex
```

`configure show` displays the active origin and access key ID, identifies the
credential mode, and always redacts the secret. Run `kooyahq configure clear`
to remove the local profile. Revoke a personal key in Account Settings to
invalidate it server-side. Organization administrators grant or revoke each
member's API access from the organization's People page.

The exact compatibility start and deadline, credential invalidation behavior,
and recovery steps are in the [credential migration guide](credential-migration.md).

## Install MCP

```sh
kooyahq mcp install --client codex
kooyahq mcp doctor --client codex --online
```

Restart the target client after installation. Use `kooyahq mcp manual` for
manual-only clients and review the absolute executable descriptor before adding
it. Hosted web clients require a separate authenticated HTTPS gateway.

## Troubleshooting

- A UUID validation error means a legacy Mongo identifier or display key was
  supplied where the new PostgreSQL API requires an entity UUID.
- Exit code `3` means the access key is invalid, expired or revoked.
- Exit code `4` means the membership or permission does not authorize the
  tenant resource.
- A missing `--company` error means the account belongs to multiple companies;
  pass the desired UUID on the command. The selector is per-call and is not
  stored in the profile or MCP server.
- A company API access rejection means an organization administrator must
  enable the member's API grant on the People page.
- Run `kooyahq mcp doctor --client <client> --online` to verify the local MCP
  registration and authenticated API status without printing credentials.
