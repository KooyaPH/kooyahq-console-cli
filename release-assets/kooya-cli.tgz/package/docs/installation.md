# Install the KooyaHQ CLI and local MCP server

The public `@kooya/cli` release package includes both `kooyahq` and `kooyahq-mcp`.
It requires Node.js 22 or newer on macOS, Windows, or Linux. The default API is
`https://console.hq.kooyaai.com/api/v1`. Entity and organization identifiers
are UUID values.

## Install

Run these commands in Terminal, PowerShell, or your Linux shell:

```sh
npm install -g https://github.com/KooyaPH/kooyahq-console-cli/releases/latest/download/kooya-cli.tgz
kooyahq --version
kooyahq-mcp --version
```

The release tarball is available from the [public GitHub releases](https://github.com/KooyaPH/kooyahq-console-cli/releases).

### Replace an earlier GitHub CLI install

The earlier public `kooyahq-cli` package uses the same command names. Remove it
before installing this Console CLI so its global command links do not conflict:

```sh
npm uninstall -g kooyahq-cli
npm install -g https://github.com/KooyaPH/kooyahq-console-cli/releases/latest/download/kooya-cli.tgz
kooyahq configure
```

The earlier profile does not include an organization UUID, so it is not migrated
automatically. Configure this CLI with the organization UUID and a valid
credential. The saved profile is replaced only after the new credential passes
`GET /api/v1/whoami`. If the existing key is rejected, create a CLI credential
in Console or Headquarters settings first.

## Configure a profile

Run `kooyahq configure`. Supply:

1. Console base origin, normally `https://console.hq.kooyaai.com`.
2. The exact organization UUID shown in Console.
3. The access key ID created in Console or Headquarters Settings.
4. The one-time secret access key.

Both Console operator and Headquarters member keys require an organization
UUID. The client validates the profile with `GET /api/v1/whoami`. It stores the
organization context with the credential and sends `X-Kooya-Organization-Id`
on API requests. Authorization remains enforced by the API.

Automation must provide all four values together:

```sh
export KOOYAHQ_BASE_URL=https://console.hq.kooyaai.com
export KOOYAHQ_ORGANIZATION_ID=123e4567-e89b-42d3-a456-426614174000
export KOOYAHQ_ACCESS_KEY_ID=your-access-key-id
export KOOYAHQ_SECRET_ACCESS_KEY=your-secret-access-key
kooyahq auth whoami --output json
```

Missing, blank, partial, non-UUID, non-HTTPS, or path-bearing configuration is
rejected before network traffic. HTTP is accepted only for localhost.

## Verify and update

```sh
kooyahq update --check
kooyahq update
kooyahq configure show
kooyahq auth whoami --output json
```

`update` installs the latest stable GitHub release asset only when the current CLI is
an npm global installation. For a source checkout, `npx`, or another install
method, run `npm install -g https://github.com/KooyaPH/kooyahq-console-cli/releases/latest/download/kooya-cli.tgz` manually. Your saved profile is
not changed by the updater. After an update, check the MCP registration:

```sh
kooyahq mcp doctor --client codex
```

`configure show` displays the active origin, access key ID and organization UUID
while always redacting the secret. Run `kooyahq configure clear` to remove the
local profile; revoke the key in Console to invalidate it server-side.

## Install MCP

```sh
kooyahq mcp install --client codex
kooyahq mcp doctor --client codex --online
```

Restart the target client after installation. Use `kooyahq mcp manual` for
manual-only clients and review the absolute executable descriptor before adding
it. Hosted web clients require a separate authenticated HTTPS gateway.

## Troubleshooting

- A UUID validation error means a legacy Mongo identifier or display key was
  supplied where the new PostgreSQL API requires an entity UUID.
- Exit code `3` means the access key is invalid, expired or revoked.
- Exit code `4` means the membership or permission does not authorize the
  tenant resource.
- A tenant-context rejection means the organization UUID is not available to
  that key, even if the key itself is valid.
- Run `kooyahq mcp doctor --client <client> --online` to verify the local MCP
  registration and authenticated API status without printing credentials.
