# Personal keys and legacy company keys

## Personal API key

Create, replace, or revoke your personal API key from Headquarters Account
Settings. Creating or replacing it requires a fresh human browser session. The
secret is shown once. The CLI stores it in its private local profile and never
shows it in `kooyahq configure show`.

The key identifies your account; it does not grant access to every company.
Company API access is a separate per-member grant, controlled by an authorized
company administrator from the organization's People page. The API also checks
your current role permission for each operation.

The CLI discovers all active memberships. A single company is selected
automatically. With multiple memberships, pass `--company <uuid>` on every CLI
operation or `company` on every MCP call. Selection is per call and is not
saved. A selected company is accessed through a lease that lasts five minutes;
the server rechecks your key, membership, API grant, and operation permission
for each request.

## Legacy transition

The thirty-day transition starts when the organization API migration is applied
to a database. Its UTC start and fixed deadline are independent in staging and
production. Re-deploying does not extend the window.

During the transition, company-bound keys require an explicit `--company
<uuid>` on every CLI command. A saved legacy company ID or
`KOOYAHQ_ORGANIZATION_ID` does not count as selection. The server returns the
transition's UTC start and deadline with each accepted legacy request, and the
CLI prints both. Revoking a member's company API grant blocks the key
immediately. At the deadline, legacy keys stop working.

Creating a personal key revokes the user's active company-bound CLI credentials
across their company memberships and expires Knowledge sessions derived from
those keys. The new secret is shown once. Legacy access fails closed if its
migration policy is missing or expired.

## Recovery

If a personal key is lost, sign in to Headquarters and replace it in Account
Settings. Then run `kooyahq configure` again with the new secret. If the CLI
reports company API access is disabled, ask a company administrator to grant
your member account API access. If an operation reports a missing permission,
ask an organization administrator to update your role through the normal role
controls.

Do not put secrets in command-line flags, shell history, MCP configuration, or
issue comments. Do not restore revoked credentials from a backup; create a new
key and preserve the revocation state.
