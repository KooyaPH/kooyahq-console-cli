# Company Knowledge client

This unreleased feature requires an enabled KooyaHQ control plane, managed Knowledge hosting or BYOKB (Bring Your Own Knowledge Base), and an explicit company-member binding. With BYOKB, the customer runs the Knowledge node on their own server and supplies a reachable endpoint or VPN. Existing Documentation is separate. A company administrator supplies the node and path grants; installing the CLI alone does not provision storage. BYOKB and application BYODB are independent options.

Use the normal personal-key `kooyahq configure` profile. For accounts with
multiple company memberships, pass `--company <uuid>` to each Knowledge command
and MCP call; the selected company is not stored as a default. The company must
also grant API access to your member account. Install the platform OpenSSH
client and ensure the node's dedicated SSH endpoint is reachable directly or
through the customer's VPN. The API issues a short-lived certificate and pins
the SSH host key; your private key remains local. The client automatically
reuses an SSH connection through a private helper and renews expired sessions.
`kooyahq configure clear` stops that helper.

Platform-scoped credentials cannot create or authorize organization Knowledge
sessions. New sessions use a company lease from the personal key; legacy
company-bound sessions remain subject to the documented thirty-day transition
and immediate revocation rules in the [credential migration guide](credential-migration.md).

For an isolated client profile, set `KOOYAHQ_CLI_HOME` to an existing absolute directory owned by the current user with private permissions (`0700` on Linux/macOS). CLI and MCP then keep configuration in `<directory>/.kooyahq/config.json` and the Knowledge helper, key and socket in `<directory>/.kooyahq/knowledge/`. The override rejects relative paths, NULs, symlinked roots/profile paths and nonprivate POSIX directories. Create the private directory first; `~` is not expanded. Without this variable, the current user-home profile remains the default. Use `kooyahq configure clear` with the same override to stop only that profile's helper and remove its stored credentials.

```sh
kooyahq knowledge status --output json
kooyahq knowledge spaces --output json
kooyahq knowledge list --path public/ --output json
kooyahq knowledge search --query 'annual leave' --output json
kooyahq knowledge read --path public/leave.md --output json
kooyahq knowledge read --reference '<reference returned by search>' --output json
kooyahq knowledge stat --path public/leave.md --output json
```

The list response returns immediate children and an optional `nextCursor`. Pass it using `--cursor`; restart listing if the generation or policy changed. Search and read return bounded source text and immutable UTF-8 byte references. Historical references still require current permission. Continue a truncated read with its returned continuation reference; use `--references '["ref1","ref2"]'` for up to four reads or `--outline true` for an outline.

Create Markdown with `knowledge create --path public/new.md --body-file ./new.md --expected-revision absent --idempotency-key <stable-key>`. A known-path read returns the source text and matching revision together; use that revision directly for the update. `knowledge stat` remains available for metadata-only checks. To replace a full document, use `knowledge replace` with `--body-file`, the exact current `--expected-revision`, and a stable `--idempotency-key`. To edit only a known span, use `knowledge patch` with `--old-text`, `--new-text`, the current `--expected-revision` from stat and a stable key. The exact old text must match once. Delete also requires a current revision and key. Every CLI write prompts for confirmation; use `--yes` only after reviewing the exact target and payload. `--dry-run` validates without sending the operation. Text whitespace is preserved.

For a bounded sequential batch, create a JSON manifest and keep the source files beside it. The manifest accepts 1–20 unique destinations, `.md` local files, explicit expected revisions, and unique per-file idempotency keys. Total document content is capped at 8 MiB. The CLI stops on the first failed or uncertain item and returns completed receipts plus the remaining paths. Rerun the unchanged manifest with the same keys to recover receipts safely; the batch is not atomic across files.

```json
{
  "items": [
    {
      "path": "public/policies/leave.md",
      "file": "leave.md",
      "expectedRevision": "revision-returned-by-read",
      "idempotencyKey": "leave-policy-2026-01"
    }
  ]
}
```

```sh
kooyahq knowledge batch --manifest-file ./knowledge-batch.json --company <company-uuid>
```

After an uncertain reply, retry the identical request/key or use `knowledge receipt --idempotency-key <key>`. Do not invent a new key for the same uncertain mutation. Changing the payload under an existing key conflicts. `knowledge history --path public/leave.md` returns immutable references; deletion retains authorized history.

For agent integration, configure a local stdio server running one of:

```sh
kooyahq-mcp --knowledge
kooyahq-mcp --knowledge-write
```

The first exposes read-only `knowledge_search` and `knowledge_read`. The second additionally exposes `knowledge_stat`, `knowledge_update`, and `knowledge_batch`. Every write tool requires `confirm: true`. `knowledge_update` accepts inline text or a local Markdown `bodyFile` up to 8 MiB; `knowledge_batch` reads a bounded local manifest and source files. The generic MCP profile also discovers Knowledge commands; generic mutations require `confirm: true`. Company Knowledge does not require an unrelated project name. The server rechecks current CLI and Knowledge permissions for every operation, including an existing connection; an authority outage denies access.

Linux client/helper and real Ubuntu node trials passed in the development qualification. Windows/macOS helper behavior, official release signing, full authenticated application journeys and production capacity remain release gates. This document describes source capability, not availability in the current public CLI release.

Knowledge write-profile MCP replies retain full revision/receipt metadata in one compact JSON text payload. The generic MCP profile retains its existing structured response contract.
