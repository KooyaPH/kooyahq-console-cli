# KooyaHQ CLI and MCP scenarios

Use discovery before every workflow whose contract is not already visible in the current session. The examples use placeholders deliberately; replace them only with exact values returned by KooyaHQ.

## Read-only discovery

CLI:

```sh
kooyahq --skill boards --output json
kooyahq boards list --all --output json
kooyahq --skill tickets list --output json
```

MCP:

1. Call `kooyahq_discover` with `{ "scope": "boards" }`.
2. Call `kooyahq_call` with `{ "command": "boards list", "all": true }`.
3. Keep the exact board ID or key returned by the read.

## Create board work and clean it up

Discover `boards create`, `tickets create`, `tickets get`, `tickets delete`, and `boards delete`. Dry-run each mutation first. Example MCP dry-run:

```json
{
  "command": "boards create",
  "company": "123e4567-e89b-42d3-a456-426614174000",
  "confirm": true,
  "dryRun": true,
  "args": {
    "project-id": "123e4567-e89b-42d3-a456-426614174011",
    "name": "API verification"
  }
}
```

After reviewing the request, repeat without `dryRun`. Create the ticket against the exact returned board selector, read it back, and verify all fields. Cleanup is part of the scenario: delete the temporary ticket, verify it is absent, delete the temporary board, and verify the board is absent. Do not leave test data behind.

## Move or reorder a ticket

1. Discover `tickets move` and read the source ticket plus destination board.
2. Select the destination by exact board ID or key.
3. Select placement using one discovered semantic option: `before`, `after`, `first`, or `last`.
4. Call a dry-run with the selected `company` UUID when the account has multiple memberships.
5. Execute after checking the target and placement, supplying `confirm: true` when the command requires it.
6. Read the ticket and destination ordering again. Report an API error rather than changing the database directly.

## Mutations and confirmation

MCP mutations follow the discovered command contract. Use `dryRun: true` where supported, include `company` on every call when the account has multiple memberships, and set `confirm: true` for every non-GET call. Destructive commands also have command-specific confirmation. Company selection is not remembered between calls. The API checks company grants and business permissions; a dry-run does not prove that the API authorized or applied a change, so always verify with a read.

For the human CLI, use `--dry-run`, then execute interactively. Use `--yes` only where discovery documents that flag and the user has already approved the exact mutation.

## Person-first work sessions and project allocations

List projects, then use the matching project IDs in the allocation JSON. Read the active session and allocation IDs and versions before changing an existing allocation:

```sh
kooyahq projects list --all --output json
kooyahq time live --scope mine --output json
kooyahq time sessions start --allocations '[{"projectId":"123e4567-e89b-42d3-a456-426614174000","description":"Release review"}]'
kooyahq time allocations pause --allocation-id 123e4567-e89b-42d3-a456-426614174001 --expected-version 2 --reason "Break"
kooyahq time allocations resume --allocation-id 123e4567-e89b-42d3-a456-426614174001 --expected-version 3
kooyahq time allocations stop --allocation-id 123e4567-e89b-42d3-a456-426614174001 --expected-version 4
kooyahq time allocations add-task --allocation-id 123e4567-e89b-42d3-a456-426614174001 --task "Review handoff"
kooyahq time sessions end --session-id 123e4567-e89b-42d3-a456-426614174002 --expected-version 5
```

Each work session start accepts one to twenty unique project allocations. Each allocation requires a project UUID and description and may also include ticket or task UUIDs. The session and allocation lifecycle commands require exact UUIDs and current expected versions; refresh `time live --scope mine --output json` after a version conflict. Mutations still require server authorization for the caller and organization.

When you are finished for the day, `kooyahq time workday end` closes the workday through the existing Time service. This also sends the configured end-of-day summary notification. Use it when you intend to end the full workday, rather than when you only need to stop one allocation.

## Troubleshoot Codex startup

If Codex reports `No such file or directory`, `Tools: none`, or startup incomplete:

```sh
npm install -g https://github.com/KooyaPH/kooyahq-console-cli/releases/latest/download/kooya-cli.tgz
hash -r
kooyahq mcp install --client codex
kooyahq mcp doctor --client codex
```

Restart Codex and open a new thread. `Auth: Unsupported` alone is expected for a local stdio server; it is different from a startup failure. Use `--online` only to add an authenticated profile check after the local doctor passes.

## Verification and cleanup checklist

- Read the target before mutation and retain its exact selector.
- Dry-run and review the normalized request.
- Execute only with explicit confirmation.
- Read the target after mutation and compare the intended fields or order.
- Stop any allocation created for a test and end its work session when appropriate.
- Delete temporary tickets before their temporary board.
- Verify cleanup with a final read or list.
- Never bypass the API with direct database edits.
