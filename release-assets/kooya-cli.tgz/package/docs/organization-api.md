# Organization API discovery and requests

The Console CLI and its bundled MCP server use the organization-only OpenAPI
contract served by the KooyaHQ API. This is the current Console CLI package
(`@kooya/cli`, `kooyahq`, and `kooyahq-mcp`), not the older standalone CLI.
The contract omits Platform Console routes. Calls reach the same organization
handlers as Headquarters, so the company API grant and current domain/resource
permissions continue to apply.

## Discover operations

```sh
kooyahq api operations
kooyahq api operations --domain knowledge
kooyahq api operations --operation organization.projects.update
```

The default listing is compact to keep agent context small. It includes the
operation ID, method, route, summary, parameter names, required fields, and
mutation status. `--operation` returns the full parameter and JSON request body
schema for one operation. Request DTO schemas are produced from the same
class-validator rules used by the API's validation pipe, so required fields,
scalar types, enum choices and common bounds stay aligned with server input
validation. The CLI reads the live contract, so clients do not need a generated
command catalog for every organization feature.

MCP exposes the same contract through `kooyahq_api_discover`. Pass `domain` to
filter the compact list or `operationId` to inspect one operation in detail.

## Call an operation

```sh
kooyahq api request organization.projects.update \
  --company 123e4567-e89b-42d3-a456-426614174000 \
  --path-params '{"projectId":"123e4567-e89b-42d3-a456-426614174001"}' \
  --body '{"name":"Roadmap"}' \
  --idempotency-key retry-2026-04 \
  --yes
```

Supply only parameters declared by the operation. Path values are URL-encoded,
query array values are repeated, and undeclared parameters fail locally. The
CLI sets authorization and company selection itself; callers cannot override
the API key or selected company through custom headers. JSON request bodies are
limited to 2 MiB. The server validates DTOs and applies the operation's normal
authorization, audit, entitlement, and resource checks.

Every non-GET request requires `--yes`. The MCP tool `kooyahq_api_call` requires
`confirm: true` for the same requests. Both select a company per call and do
not persist a current company. A personal key is exchanged for a five-minute
company lease before the operation is sent. Legacy company keys must repeat
their company selector and are accepted only during the fixed migration
window.

`--dry-run` prints the selected operation and supplied JSON without loading
credentials or making network requests. It cannot verify that the operation or
parameters exist in the live contract. Generic JSON calls do not implement
multipart file transfers. The organization contract identifies successful
binary responses; save them with `--output-file <path>`. Responses are capped at
100 MiB, written atomically with mode `0600`, and never overwrite an existing
file unless `--force` is passed. `--force` only replaces a regular file and
refuses symbolic links. The signed media upload and download capability routes
are omitted from generic API discovery so short-lived storage URLs are not
returned to an agent.

Upload files through the bounded signed-transfer helper:

```sh
kooyahq media upload --company 123e4567-e89b-42d3-a456-426614174000 \
  --file ./receipt.pdf --purpose attachment --content-type application/pdf --yes
```

The CLI sends the file directly to the storage URL returned by the company API,
then finalizes the object through the same company lease. It does not print or
return the signed URL. Each upload is capped at 100 MiB. If bytes reach storage
but finalization is uncertain, the CLI reports the media object ID so the owner
can recover through the declared `organization.media.upload.complete` operation.

Knowledge document content stays on its restricted direct SSH transport. Use
`knowledge search`, `knowledge read`, `knowledge create`, `knowledge patch`, and
the other dedicated Knowledge commands for document content. The organization
API exposes only explicit Knowledge management and metadata operations; the
generic `/tenant/knowledge/{operation}` route is excluded from discovery and
rejects company API lease calls.

## MCP tools

- `kooyahq_api_discover` returns compact operation metadata or a detailed
  operation schema.
- `kooyahq_api_call` accepts `operationId`, optional per-call `company`,
  `pathParams`, `query`, declared `headers`, JSON `body`, and
  `idempotencyKey`. Binary responses can use `outputFile` and `force`.
  Mutations require `confirm: true`.
- `kooyahq_call` can invoke `media upload` with a local `file` path, `purpose`,
  and `content-type`; pass `confirm: true` for the upload.

Use `kooyahq_discover` and `kooyahq_call` for the stable command catalog. The
generic API tools expose approved organization handlers that are not yet
represented by dedicated command names. Neither tool surface exposes platform
operator operations.
