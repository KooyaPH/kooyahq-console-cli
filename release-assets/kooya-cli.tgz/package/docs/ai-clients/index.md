# KooyaHQ AI client tutorials

Install and configure the KooyaHQ CLI first. The local MCP server is a stdio process, so it runs on the same computer as the AI client and uses that computer's KooyaHQ profile. It never exposes the profile to a browser or hosted agent.

## Shared preparation

On Linux, macOS, or Windows, install Node.js 22 or newer and the public CLI package. Then configure and verify the local profile:

```sh
npm install -g https://github.com/KooyaPH/kooyahq-console-cli/releases/latest/download/kooya-cli.tgz
kooyahq configure
kooyahq auth whoami --output json
```

For a manual stdio entry, obtain absolute targets. On Windows, use forward slashes when placing paths in JSON.

```sh
node -p "process.execPath"
npm root -g
```

Every JSON-backed installer writes the local server below its `mcpServers.kooyahq` entry. The entry always uses the Node.js path as `command` and this script as its only argument:

```text
<npm-global-root>/@kooya/cli/dist/bin/kooyahq-mcp.js
```

## Cursor

Run this on the same operating system as the target Cursor client. Cursor desktop and Cursor Agent can share `~/.cursor/mcp.json` only when they use the same OS home directory:

```sh
kooyahq mcp install --client cursor
kooyahq mcp doctor --client cursor --online
cursor-agent mcp list
cursor-agent mcp list-tools kooyahq
```

Restart the Cursor desktop app after installation. The expected tools are `kooyahq_status`, `kooyahq_discover`, `kooyahq_call`, `kooyahq_api_discover`, and `kooyahq_api_call`.

See [the Cursor tutorial](cursor.md) for recovery and safe use.

## Claude Code

```sh
kooyahq mcp install --client claude
claude mcp get kooyahq
```

See [the Claude Code tutorial](claude.md). Claude's lookup is text-only, so its KooyaHQ doctor deliberately fails closed instead of claiming an exact descriptor check. Claude.ai web connectors require a remote MCP gateway; they cannot start this local process.

## Gemini CLI

```sh
kooyahq mcp install --client gemini
kooyahq mcp doctor --client gemini --online
```

See [the Gemini CLI tutorial](gemini.md). Keep tool approval enabled; do not set the server to trusted or auto-run.

## Google Antigravity

```sh
kooyahq mcp install --client antigravity
kooyahq mcp doctor --client antigravity --online
```

See [the Google Antigravity tutorial](antigravity.md).

## Hermes Agent

```sh
kooyahq mcp manual --client hermes
```

See [the Hermes Agent tutorial](hermes.md). This prints the absolute YAML entry without modifying Hermes. Do not use `hermes import-agent` with secret migration: the KooyaHQ profile remains managed only by `kooyahq configure`.

## Safe workflow for every local client

1. Call `kooyahq_status` to establish the acting identity.
2. Call `kooyahq_discover` for the exact command.
3. For multiple company memberships, pass the intended company UUID in each call's `company` field.
4. Read the target board or ticket with an exact selector.
5. Preview consequential mutations with `dryRun: true` when supported and supply `confirm: true` for every non-GET call.
6. Read back the result and clean up temporary test data.

The API checks company grants and resource permissions for every operation.
MCP does not expose platform-console administration.

## ChatGPT, Replit, and other web environments

ChatGPT remote MCP, OpenAI Responses API, Replit Agent, Gemini web/API, and Claude.ai web connectors are remote environments. **Remote gateway required:** the local `kooyahq-mcp` process cannot be installed into them and no `kooyahq mcp install --client chatgpt` or `--client replit` command exists.

Before documenting a web installation, KooyaHQ must deploy a separately reviewed HTTPS Streamable HTTP or SSE MCP gateway with per-user authentication, company selection, backend-enforced grant and permission checks, approval controls, rate limits, audit events, health checks, and credential-revocation procedures. Never tunnel or expose a developer's local KooyaHQ profile. See [the hosted-client boundary](web-and-remote.md).

## Recovery

If a client reports a missing executable, reinstall the CLI, regenerate its entry with the appropriate installer or manual configuration, then restart the client. If `kooyahq mcp doctor --client cursor --online` fails, re-run `kooyahq configure`; never paste the secret into an MCP configuration file.
