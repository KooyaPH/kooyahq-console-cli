# KooyaHQ MCP for Gemini CLI

Gemini CLI runs KooyaHQ as a local stdio MCP server with the current machine's KooyaHQ profile.

## Install

```sh
kooyahq mcp install --client gemini
```

The installer updates only the `kooyahq` entry in `~/.gemini/settings.json` and preserves other `mcpServers` entries.

## Verify

```sh
kooyahq mcp doctor --client gemini --online
```

Restart Gemini CLI, then use its MCP management view (for example `/mcp list`) to confirm the five KooyaHQ tools are available: `kooyahq_status`, `kooyahq_discover`, `kooyahq_call`, `kooyahq_api_discover`, and `kooyahq_api_call`.

## Use safely

Start with status, discover the command, and read the target before a mutation. For multiple company memberships, include the company UUID in the call's `company` field. Preview consequential changes with `dryRun: true` when supported, set `confirm: true` for every non-GET call, then read the resource back and clean up test data. Company grants and business permissions are checked by the API.

## Troubleshooting and recovery

If the entry is missing or old, rerun the installer; it refuses malformed configuration rather than overwriting it. If the online doctor fails, repair the local profile using `kooyahq configure`. Do not add environment secrets to `settings.json`.
